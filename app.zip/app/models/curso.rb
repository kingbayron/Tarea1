class Curso < ApplicationRecord
end
